sayi= 10  #integer
deger = "10" #string
isim = "furkan"
soyisim = "çalışkan"
tc = "11111111111"
floatSayi = 10.0

print(float(tc) + 10)
print(type(floatSayi))
print(type(sayi))
print(type(tc))


