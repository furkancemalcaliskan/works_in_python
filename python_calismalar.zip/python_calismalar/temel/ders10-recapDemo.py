

lights = ["red", "yellow", "green"]

currentLight = lights[2]

print(currentLight)

if currentLight == "red":
    print("STOP")    
elif currentLight == "yellow":
    print("READY!")
#elif currentLight == "green":
else:
    print("GO!")
