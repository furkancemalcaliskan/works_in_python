#input

ad = input("Adınız?")
print(ad)

sayi1 = input("Sayı 1 = ?")
sayi2 = input("Sayı 2 = ?")

print(int(sayi1)+int(sayi2))