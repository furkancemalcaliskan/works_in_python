
# Şart Blokları

sayi1 = 30
sayi2 = 20

if sayi1 > sayi2:
    print("Birşey")
    print("Birşey daha")
print("başka birşey daha")