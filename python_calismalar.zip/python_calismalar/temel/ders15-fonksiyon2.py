#RETURN EDEN FONK

#def dikUcgenAlaniHesapla(a,b):
    #return a*b/2

#alan = dikUcgenAlaniHesapla(2,3)

#print(alan)

dikUcgen2 = lambda a,b : a*b/2

print(dikUcgen2(3,6))