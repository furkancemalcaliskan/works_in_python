#sayilarin yerini degistir

x = 10
y = 20

temp = x

x = y
y = temp

print("x = " + str(x))
print("y = " + str(y))