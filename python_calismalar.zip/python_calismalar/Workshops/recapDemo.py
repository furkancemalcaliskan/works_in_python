

sayi = input("Kaç yıldız olsun?")

yıldız = ""

for x in range(1,int(sayi) + 1):
    yıldız = yıldız + "*"
    print(yıldız)