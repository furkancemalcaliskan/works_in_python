

sayi = int(input("Bir Sayi Giriniz"))

if sayi<0:
    print("Negatif sayı")
else:
    print("Pozitif sayı")