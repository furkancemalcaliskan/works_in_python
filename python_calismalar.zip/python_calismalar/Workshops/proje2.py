#kac mile eder

km = int(input("Kaç km?"))

mile = km * 0.621371192

print(str(km) +" km = " + str(mile) + " mil eder.")