# kelime sıralama

cumle = "bugün hava çok güzel"

kelimeler = cumle.split()

kelimeler.sort()

print(kelimeler)

for kelime in kelimeler:
    print(kelime)