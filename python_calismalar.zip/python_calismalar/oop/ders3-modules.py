#import matematikModule

#matematikModule.topla(2,3)
#matematikModule.carp(2,3)

# import matematikModule as mm

# mm.carp(2,4)
# mm.topla(2,4)

# print(mm.musteri["firstname"])

from matematikModule import topla

topla(2,4)

from matematikModule import musteri

print(musteri["firstname"])