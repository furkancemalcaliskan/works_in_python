

def topla(sayi1,sayi2):
    print("Toplam : " + str(sayi1+sayi2))

def carp(sayi1,sayi2):
    print("Çarpım : " + str(sayi1*sayi2))

musteri = {
    "firstname":"Furkan",
    "lastname":"Çalışkan"
}